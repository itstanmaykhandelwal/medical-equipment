import { useEffect, useState } from "react";
import { useNavigate } from "react-router-dom";
import {
    LayoutDashboard,
    Package,
    ShoppingCart,
    Users,
    LogOut,
    RefreshCw,
} from "lucide-react";
import { adminRequest } from "../services/api";

export default function Dashboard() {
    const navigate = useNavigate();
    const [dashboard, setDashboard] = useState(null);
    const [loading, setLoading] = useState(true);
    const [error, setError] = useState("");

    useEffect(() => {
        const token = localStorage.getItem("medical-admin-token");

        if (!token) {
            navigate("/admin/login", { replace: true });
            return;
        }

        const loadDashboard = async () => {
            try {
                const data = await adminRequest("/api/admin/dashboard");
                setDashboard(data);
            } catch (err) {
                setError(err.message);

                if (
                    /session|token|unauthorized|forbidden|expired/i.test(
                        err.message,
                    )
                ) {
                    localStorage.removeItem("medical-admin-token");
                    navigate("/admin/login", { replace: true });
                }
            } finally {
                setLoading(false);
            }
        };

        loadDashboard();
    }, [navigate]);

    const handleLogout = () => {
        localStorage.removeItem("medical-admin-token");
        navigate("/admin/login", { replace: true });
    };

    return (
        <div className="admin-layout">
            <aside className="admin-sidebar">
                <div className="admin-brand">
                    <Package size={25} />
                    <span>MedEquip Admin</span>
                </div>

                <nav>
                    <div className="admin-nav-item active">
                        <LayoutDashboard size={19} />
                        Dashboard
                    </div>
                    <div className="admin-nav-item">
                        <Package size={19} />
                        Products
                    </div>
                    <div className="admin-nav-item">
                        <ShoppingCart size={19} />
                        Orders
                    </div>
                    <div className="admin-nav-item">
                        <Users size={19} />
                        Customers
                    </div>
                </nav>

                <button className="admin-logout" onClick={handleLogout}>
                    <LogOut size={18} />
                    Logout
                </button>
            </aside>

            <main className="admin-main">
                <header className="admin-topbar">
                    <div>
                        <h1>Dashboard</h1>
                        <p>Medical equipment store overview</p>
                    </div>
                    <span className="admin-status">Admin Portal</span>
                </header>

                {loading ? (
                    <div className="admin-message">Loading dashboard...</div>
                ) : error ? (
                    <div className="admin-error">
                        <div>{error}</div>
                        <button onClick={() => window.location.reload()}>
                            <RefreshCw size={16} /> Retry
                        </button>
                    </div>
                ) : (
                    <>
                        <div className="admin-welcome">
                            <h2>Welcome back!</h2>
                            <p>
                                Your admin authentication and dashboard
                                connection are being verified.
                            </p>
                        </div>

                        <section className="admin-stat-grid">
                            <article className="admin-stat-card">
                                <Package size={23} />
                                <span>Total Products</span>
                                <strong>—</strong>
                            </article>

                            <article className="admin-stat-card">
                                <ShoppingCart size={23} />
                                <span>Total Orders</span>
                                <strong>—</strong>
                            </article>

                            <article className="admin-stat-card">
                                <Users size={23} />
                                <span>Total Customers</span>
                                <strong>—</strong>
                            </article>
                        </section>

                        <section className="admin-data-panel">
                            <h3>Backend response</h3>
                            <p>
                                Connected to the protected dashboard endpoint.
                            </p>
                            <pre>{JSON.stringify(dashboard, null, 2)}</pre>
                        </section>
                    </>
                )}
            </main>
        </div>
    );
}
