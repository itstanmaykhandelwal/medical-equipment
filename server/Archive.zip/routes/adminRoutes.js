const express = require("express");
const bcrypt = require("bcryptjs");
const jwt = require("jsonwebtoken");

const User = require("../models/User");
const authMiddleware = require("../middleware/authMiddleware");
const adminMiddleware = require("../middleware/adminMiddleware");

const router = express.Router();

// Create admin account using the private setup key
router.post("/setup", async (req, res) => {
    try {
        const { name, email, password, setupKey } = req.body;

        if (!process.env.ADMIN_SETUP_KEY) {
            return res.status(500).json({
                success: false,
                message: "Admin setup is not configured.",
            });
        }

        if (!setupKey || setupKey !== process.env.ADMIN_SETUP_KEY) {
            return res.status(403).json({
                success: false,
                message: "Invalid setup key.",
            });
        }

        if (
            !name?.trim() ||
            !email?.trim() ||
            typeof password !== "string" ||
            password.length < 8
        ) {
            return res.status(400).json({
                success: false,
                message:
                    "Name, email and password of at least 8 characters are required.",
            });
        }

        const normalizedEmail = email.trim().toLowerCase();

        const existingUser = await User.findOne({
            email: normalizedEmail,
        });

        if (existingUser) {
            return res.status(409).json({
                success: false,
                message:
                    existingUser.role === "admin"
                        ? "An admin account already exists for this email."
                        : "This email already belongs to a customer account.",
            });
        }

        const hashedPassword = await bcrypt.hash(password, 12);

        const user = await User.create({
            name: name.trim(),
            email: normalizedEmail,
            password: hashedPassword,
            role: "admin",
        });

        return res.status(201).json({
            success: true,
            message: "Admin account created successfully.",
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role,
            },
        });
    } catch (error) {
        console.error("Admin setup error:", error.message);

        return res.status(500).json({
            success: false,
            message: "Unable to create admin account.",
        });
    }
});

// Admin login
router.post("/login", async (req, res) => {
    try {
        const { email, password } = req.body;

        if (
            typeof email !== "string" ||
            typeof password !== "string" ||
            !email.trim() ||
            !password
        ) {
            return res.status(400).json({
                success: false,
                message: "Email and password are required.",
            });
        }

        const user = await User.findOne({
            email: email.trim().toLowerCase(),
        }).select("+password");

        if (!user || user.role !== "admin") {
            return res.status(401).json({
                success: false,
                message: "Invalid admin credentials.",
            });
        }

        const passwordMatches = await bcrypt.compare(password, user.password);

        if (!passwordMatches) {
            return res.status(401).json({
                success: false,
                message: "Invalid admin credentials.",
            });
        }

        if (!process.env.JWT_SECRET) {
            throw new Error("JWT_SECRET is not configured.");
        }

        const token = jwt.sign(
            {
                userId: user._id.toString(),
                role: "admin",
            },
            process.env.JWT_SECRET,
            { expiresIn: "1d" },
        );

        return res.status(200).json({
            success: true,
            message: "Admin login successful.",
            token,
            user: {
                id: user._id,
                name: user.name,
                email: user.email,
                role: user.role,
            },
        });
    } catch (error) {
        console.error("Admin login error:", error);

        return res.status(500).json({
            success: false,
            message: "Unable to log in as admin.",
        });
    }
});

// Protected admin dashboard test endpoint
router.get("/dashboard", authMiddleware, adminMiddleware, (req, res) => {
    return res.status(200).json({
        success: true,
        message: "Welcome to the admin dashboard!",
        userId: req.user.userId,
    });
});

module.exports = router;
